function loginSubmit(id1,password1)
{
	//alert(name1+" "+content1+" "+dept);
	var user = new Object(); //创建对象 
	//alert(id1+"\n"+password1);
	user.userPhone=id1;
	user.userPwd=password1;
	alert(user.userPhone+"\n"+userPwd);
	return user;
}